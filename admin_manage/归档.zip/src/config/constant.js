/**
 * 项目中的常量
 */
export const ADMNIN_MANAGE_NAME = "后台管理系统";    // 管理后台名称
export const LOGO = require("@/assets/avatar.png");   // 管理后台logo
export const DURATION = '1200';    // message提示的延时消失时间


